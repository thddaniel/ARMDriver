Computer Access Technology                                                / \
Corporation                                                              / V \
------------------------------------------------------------------------------
                               2403 Walsh Avenue, Santa Clara, CA   95051-1302
                                    Tel: +1/408.727.6600  Fax: +1/408.727.6622

Read Me Notes for USB Chief 1.34                   Updated: September 25, 2002

Table of Contents

  Overview
  System Requirements
  Release Notes
  Known Problems and Issues
  Technical Support

------------------------------------------------------------------------------
Overview

  This Read Me file contains last-minute product information for the
  USB Chief Version 1.34 for Microsoft Windows 98, 98SE, Me, 2000, and XP. 
  For full instructions on using the USB Chief please see the User's Manual included 
  with your unit or download a PDF version of the Manual from:

    http://www.catc.com/

  If Windows NT drivers are needed please contact CATC.

------------------------------------------------------------------------------
System Requirements

  - x86-based personal computer (386 minimum; 486, Pentium, or Pentium Pro
    recommended)
  - A USB connection to the computer (unless using only as a viewer)
  - Microsoft  Windows 98SE, Me, 2000, or XP for recording
    and viewing the traffic
  - Microsoft Windows 95 or any later Windows system for viewing the traffic
  - Minimum of 16MB physical RAM, recommend 32 MB for transaction decoding
  - 10 MB hard disk space, plus additional memory for recordings (can be as
    much as 200MB when recording a full buffer size)
  - It is recommended that the resolution of the monitor be set to at least
    800x600 with thousands of colors.

------------------------------------------------------------------------------
Release Notes

  Version 1.34
  - Fix problems exporting to Generator (.utg) files
  - Warn user when loading Advisor or USBTracer files
  - Update standard descriptor decoding files to include OTG and
    Hi-Speed descriptors
    

  Version 1.33
  - Fixed both known problems in the previous version. The EOP keyword in an 
    *.UTG file can accept values of 2,3 and 4. This will result in 1 to 3 bits
    of SE0 and 1 bit of 'J' being generated.
  - Fixed problem with traffic generation when using the 'wrap' functionality.
    The SE0 signal was appearing on the bus at each wrap of traffic generation.
  - A recording option is added to avoid automatic opening of the trace file
    after uploading is done.
  - Fixed few other minor bugs.
  - Updated Bluetooth.req decoding file for 1.1 version of Bluetooth specification.
  - The document describing format of the decoding files (.req and .dsc) is now
    available on CATC web site.

  Version 1.32
  - Fixed a bug with the application hanging when displaying a transfer or a
    decoded USB request in which invalid (0-length) descriptors were returned.

  Following bugs are known in this revision:

     -  When EOP length is specified in an *.UTG file using EOP <Key Word>, 
        the generator always sends 2 bits regards of the setting.
     -  File "SAVE AS" does not work correctly if A FILE NAME WHICH ALREADY EXISTS
        IS USED AGAIN IN THE SAVE AS DIALOG.  As a work around, use non existing 
        file names.

  Version 1.31 
  - Fixed low speed generation bug
  - Included a new *.inf file to resolve installation problems in some Windows 2000
    based systems.
 
  Version 1.30 .
  - Fixed a bug with conversion of Inspector/Detective traces introduced in 
    1.21 . ( A file with Reset or Suspend/Resume couldn't be converted properly ).
  - Fixed a bug with traffic generation introduced in 1.21 . You could be 
    recording garbage if you started generation in Repeat mode and started 
    recording after that.
  - Transfer display is available in addition to transaction display. 
    Transactions are combined into Control, Interrupt, Bulk or Isochronous
    transfers and presented as units on the screen.
  - To activate this, "Show Transfers" is added in the right-click menu and 
    in Display Options\General.
  - The mechanism for decoding transactions / transfers is changed. They are 
    parsed once when first requested and saved in the trace file. Each 
    subsequent time they are loaded from the trace.
  - The format of decoding files (.req) was extended to include endpoint
    decoding. If a certain Interrupt or Bulk endpoint carries formatted data,
    one or more EndopintData blocks can be added to the .req file describing
    this protocol. This will allow to click on an IN or OUT field for this 
    endpoint and see the decoded data (very much like the request decoding).
    Examples of this can be found in the files "hub.req" and "Bluetooth.req"
    supplied by CATC.
  - The "Request Recipient <=> Class/Vendor decoding" dialog was expanded to
    includ the Endpoints tab, allowing for association of an endoint in the 
    trace with a particular decoding.
  - "Keep Across Recordings" checkbox is added in the "Request Recipient 
    <=> Class/Vendor decoding" sheet. When you are recording many times with 
    the same USB devices, you can set your decoding associations just once
    for the first trace and check this box. All the subsequent recordings
    will keep the decoding associations (provided that device addresses don't 
    change).
  - The Request and Endpoint association is used when transfers are displayed.
    For data stage of Control transfers and for Interrupt/Bulk transfer the 
    fields displayed in the transfer are built according to decoding 
    assignments.
  - Search and Hiding now work properly when transactions/transfers are 
    displayed.
  - Under "Export" menu "Transactions to text" or "Transfers to text" items are
    added when transactions/transfers are displayed, allowing to export to text.
  - "Previous" and "Next" buttons are added in the dialog presenting the decoded
    USB device request. You can use them to switch to decoding of the next or 
    previous device request in the trace without cosing the dialog. Also the 
    dialog itself is made modeless, so you can switch to the packet view and 
    scroll around.
  - The format of decoding files (.req) has several extensions. The "Name" 
    keyword is now used not only for Bitmap fields, but also for Format and Word
    fields of the data. The Name specifies the title of the field when it is
    presented while transfers are displayed. The .req files supplied by CATC
    are modified to make use of this change.
    The Depends(Databytes(x,x)) construct is added to be used in Data 
    definition for requests and endpoints.
    The Color(r,g,b) construct is added to set colors for fields of the data
    when transfers are displayed. It can also be used to color fields with some
    erroneous values with red. You can find examples of using this construct
    in the file "Bluetooth.req" supplied by CATC.
  - "Bluetooth.req" file is added to the list of request decoding files
    supplied by CATC. It defines decoding for USB-based Bluetooth HCI devices.

  NOTES for Version 1.30 .

  - If Start Of Frame packets are filtered out in a trace (during recording
    or when a trace is saved), Isochronous transfers won't be decoded properly.
    Decoding needs the SOFs to be present in order to properly recognize the
    Isochronous transfer.
  - If the recording is done with Data Truncation options, some transfers might
    not be decoded properly.


  Version 1.21 .
  - This version includes a new Windows 98/98SE/2000 driver for the USB Chief
    (usbchief.sys). Please select "Yes" when prompted for the replacement of
    the driver by the installation program.
    NOTE: No new driver for Windows 95(OSR 2.1)
  >> Application <<
  - Fixed a bug in the driver that caused the Windows 2000 system to crash on
    shutdown if USB Chief device was connected.
  - Added new menu item under "Setup" : "Breakout board". This provides more
    convenient way to set up behavior of external input and output signals on
    the USB Chief breakout board during recording.
  - Added new pop-up menu under "View" : "Hide devices". This provides more 
    convenient way to display only the address/endpoint combinations you are 
    interested in in the packet view.
  - Improved the "Go To" menu and added more event items in the Search/Hide
    dialog.
  - Added the "Wrap point" ( wrap=here ) functionality to Chief Generator files.
    Now you can separate a portion of the traffic to be sent only once in the 
    Repeat mode. The rest of the traffic will be sent repeatedly in a loop. 
    New sample Wrap.utg added.
  - Added "Auto-reload" functionality to Generator text files. When you edit
    a UTG file outside of the Chief application and switch back, the application
    offers you to re-load the UTG file.
  - Improved editing of the device request and data pattern in recording 
    events. Added bit-by-bit editing of the data pattern.
  - Improved processing of the request and descriptor definition files 
    ( Endian=Big entry implemented, the bracketing is more straightforward, some
    fixes in Audio.req file ).
  - Added timeout/turnaroud time error to error summary and search.
  - Added a warning message when saving as text is attempted while transactions 
    are shown.
  - Fixed the problem with device request decoding when the external signals 
    were saved in the trace file.
  - Fixed the problem with Save As dialog sometimes saving hidden packets when
    instructed not to.
  - Fixed the problem with converting Inspector/Detective files with bit 
    stuffing errors to Chief.
  - Fixed the problem with falsely reporting Data toggling errors.
  - Other minor bug fixes.


  Version 1.20 .
  - The major functionality added to this version is the support for the
    Secondary Record channel on the front of your USB Chief. Please remove
    the label covering the Secondary Record channel.
  - A new version of the BusEngine (1.30) is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
    A new version of the USB Chief Firmware (1.04) is included with this
    release. Please update the Firmware for your analyzer after installing the
    software. Use the "Update Firmware" button in the Setup Analyzer dialog
    window for this purpose.
  >> BusEngine <<
  - Added support for sequencing the triggering of token events, two event
    counters, and external output signaling.
  - Added a dedicated BusEngine (chief_s.rbf) that supports the Secondary
    Record channel.
  - Fixed a bug in the BusEngine that caused bus conditions to be filtered
    out of the recording when only token events where specified.
  - Updated to work as perfectly as humanly possible.
  >> Application <<
  - Added Secondary Channel... under the Setup menu. Once you setup the
    Secondary Record channel your recordings will include packets from both
    channels and labeled with 'P' or 'S' accordingly. This is extremely useful
    for recording up-stream and down-stream of a hub. Keep in mind that
    after setting up for the Secondary Channel some trigger events and the
    traffic generation will be unavailable until you switch back to the
    Primary Record setup.
  - Completed the Device request and descriptor detailed decoding. Added the
    ability to assign a specific request recipient throughout a recording
    to a class/vendor decoding group. Added definition files for Audio
    requests, HID, Hub and Audio descriptors. String descriptors are also
    supported.
  - Added the ability to sequence token events, use to event counters, and
    control the output signaling. You can control these new features from the
    Actions tab under Recording Options.
  - Revised the Save/Rename file functions to use one Save As dialog.  Here
    you can select to save the whole data.usb file as a new name (VERY FAST!)
    or a smaller portion of the file.
  - Added analysis for Babble, Frame Error, and Data Toggle Errors.  Since this
    necessitates 2 analysis scans of the entire .usb file, the user can decide
    whether to do this all the time or not by checking or leaving blank an 
    option button in the Display Options dialog.
  - Fixed a problem that raw data specified in the UTG file always results in
    a PID of value zero.
  - Fixed a problem that zero length data0/1 packets cause a page break when
    printing.
  - Fixed a problem where data0/1 packets longer than 256 bytes could be
    spuriously lost from the recording during upload.
 

  Version 1.11 .
  - This version includes the new Windows 98/98SE/2000 driver for the USB Chief
    (usbchief.sys). Please select "Yes" when prompted for the replacement of
    the driver by the installation program.
    NOTE: No new driver for Windows 95(OSR 2.1)

  - A new version of the BusEngine, 1.11 is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
  >> BusEngine <<
  - Fixed a bug in the BusEngine that caused undetected recording errors when
    a low-speed packet was sent on a full-speed branch connected to one of
    many OHCI host controllers.
  - Fixed a bug in the BusEngine that caused false triggers on a data
    toggling violation when there was none.
  - Fixed a bug in the BusEngine that caused false triggers on a bad or short
    EOP violation when there was none.
  - Fixed a bug in the BusEngine that would sometimes lead to an incorrect or
          negative time-stamp.
  >> Application <<
  - Fixed a bug in the Software that caused the USB Chief not to record
    correctly on Windows 98SE systems (fix in the driver).
  - Finished the conversion of Inspector/Detective 'dot' USB files to the USB
    Chief format. You should now be able to open any older USB files and view
    all the packets with the USB Chief application.
  - Fixed several minor problems related to search and exporting UTG files.

  Version 1.1 .
  - A new version of the BusEngine, 1.1 is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
    A new version of the USB Chief Firmware (1.03) is included with this
    release. Please update the Firmware for your analyzer after installing the
    software. Use the "Update Firmware" button in the Setup Analyzer dialog
    window for this purpose.
  - Added USB Traffic Generation for USB Chief Plus analyzers; To enable
    traffic generation you must obtain a password from CATC (support@catc.com)
  - Added Export data and View data for handling data0/1 packets
  - Added babble, loss-of-activity, and frame length violation to event
    triggering
  - Completed the Transaction Summary Report
  - Added a new graphical status bar to assist in the understanding of the
    recording and uploading process
  - Added the following standard device class request decoding: audio,
    communication, hid, monitor, power, and printer
  - Made improvements to performance when working with very large recordings
  - Fixed a bug in viewing data as ASCII and re-ordering the bits MSB->LSB
  - Fixed a problem where the default.opt file is installed with the read-only
    file flag set
  - Fixed several minor bugs

  Version 1.01 .
  - A new version of the BusEngine, 1.0 is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
  - Added standard descriptor decoding
  - Added short EOP error to search, error summary, and event triggering
  - Completed the Timing and Bus Usage calculator report
  - Fixed several minor bugs

  Version 1.0 .
  - A new version of the BusEngine, 0.94 is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
    A new version of the USB Chief Firmware (1.02) is included with this
    release. Please update the Firmware for your analyzer after installing the
    software. Use the "Update Firmware" button in the Setup Analyzer dialog
    window for this purpose.
  - More event groups have been added to the Recording Options: The BusEngine
    now triggers time-out( turn-around ) or data toggle violations and external
    input signals.
  - Added user defined hide packets and the general find packets interface
  - Completed decoding of Standard and Hub class requests
  - Added sample file VisualElements.usb
  - Timing in the packet view has improved
  - Fixed problems detecting a change from low-speed to full-speed during
    recording
  - Enhanced the request definition language to give more capabilities for
    request decoding. The full request definition files for standard and hub
    requests are included in this release. The elements of the language are
    going to be fully documented in subsequent versions of USB Chief.

  Version 0.92 .
  - Intermediate release used at the March 30th USB-IF Compliance Workshop

  Version 0.91 .
  - A new version of the BusEngine, 0.93 is included with this release. Please
    update the BusEngine for your analyzer after installing the software. Use
    the "Update BusEngine" button in the Setup Analyzer dialog window for this
    purpose.
    A new version of the USB Chief Firmware (1.01) is included with this
    release. Please update the Firmware for your analyzer after installing the
    software. Use the "Update Firmware" button in the Setup Analyzer dialog
    window for this purpose.
  - More event groups have been added to the Recording Options; The BusEngine
    now triggers on bad PID, bad bit stuffing, and bad crc
  - Timing in the packet view has improved
  - Fixed problems displaying Reset, Suspend, Resume and Low-Speed keep-alive
    signals
  - More types of search added in the Search\Go to menu
  - The "Power and Connection" modeless dialog added (invoked from Setup menu),
    allowing to setup special connection and power measuring features of the
    analyzer

  Version 0.90 .
  - This is the first released version (please read Expectations below)

------------------------------------------------------------------------------
Know Problems and Issues

  P18FEB99-hjb: There are problems running the USB Chief Application with
  an OHCI USB host controller and Windows 95 (OSR 2.1). It is recommended that
  the user upgrade to Windows 98 for Systems with OHCI USB host controllers.
  Windows 98 fixed many bugs in the OHCI USB drivers present with Windows 95
  (OSR 2.1). You can check the kind of USB host controller by selection the
  System Properties and finding the USB Controller under the Device Manager
  tab. An OHCI host controller is listed with the phrase
  "Open Host Controller".

------------------------------------------------------------------------------
Technical Support

  Online Support

  Web           http://www.catc.com/
  E-Mail        support@catc.com

  Phone Support

  Voice         +1 800 909 2282  (USA/Canada)
                +1 408 727 6600  (worldwide)
  Fax           +1 408 727 6622  (worldwide)

  Sales Information

  E-Mail        sales@catc.com



------------------------------------------------------------------------------
(c) 2002 Computer Access Technology Corporation. All rights reserved.

CATC, and USB Chief are trademarks of Computer Access Technology
Corporation. Microsoft Windows is a registered trademark of Microsoft Inc.

CATC reserves the right to revise these specifications without notice or
penalty.

